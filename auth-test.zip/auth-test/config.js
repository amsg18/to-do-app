module.exports={
    db: 'localhost/27017/SD',
    port:3100,
    secret: 'mipalabrasecreta',
    tokenExpTmp: 7*24*60//siete días expresados en segundos

}